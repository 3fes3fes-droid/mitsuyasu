import { loadFootballPayloads } from "../../archives/football/server";

export const dynamic = "force-dynamic";

export async function GET() {
  return Response.json(await loadFootballPayloads(), {
    headers: { "Cache-Control": "private, max-age=120" },
  });
}
